import React from 'react';
import { Link } from 'react-router-dom';
import './index.css';

const Navbar = ({ setSearch }) => {
  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/" className="nav-link">🎬 MovieMania</Link>
      </div>
      <ul className="navbar-links">
        <li><Link to="/" className="nav-link">Home</Link></li>
        <li><Link to="/popular" className="nav-link">Popular</Link></li>
        <li><Link to="/top-rated" className="nav-link">Top Rated</Link></li>
        <li><Link to="/upcoming" className="nav-link">Upcoming</Link></li>
        <li>
          <input
            type="text"
            placeholder="Search movies..."
            onChange={(e) => setSearch(e.target.value)}
            className="navbar-search"
          />
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
