import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from "./Project9Movie/Components/Navbar";
import Home from './Project9Movie/Home';
import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'https://api.themoviedb.org/3/',
  params: {
    api_key: import.meta.env.VITE_TMBD_API_KEY,
  },
});

const App = () => {
  const [movies, setMovies] = useState([]);
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchMovies = async () => {
    try {
      let response;

      if (search === '') {
        response = await axiosInstance.get('movie/popular', {
          params: { page: currentPage },
        });
      } else {
        response = await axiosInstance.get('search/movie', {
          params: {
            query: search,
            page: currentPage,
          },
        });
      }

      setMovies(response.data.results);
      setTotalPages(response.data.total_pages);
    } catch (error) {
      console.log('Error fetching movies:', error);
    }
  };

  useEffect(() => {
    fetchMovies();
  }, [search, currentPage]);

  return (
    <BrowserRouter>
      <Navbar setSearch={setSearch} />
      <Routes>
        <Route
          path="/"
          element={
            <Home
              movies={movies}
              currentPage={currentPage}
              totalPages={totalPages}
              handleNext={() => setCurrentPage((p) => p + 1)}
              handlePrev={() => setCurrentPage((p) => p - 1)}
            />
          }
        />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
