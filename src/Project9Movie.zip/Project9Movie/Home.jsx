import React from 'react';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import { Carousel } from 'react-responsive-carousel';
import Card from './Components/Card';
import { Link } from 'react-router-dom';
import './Home.css';


const Home = ({ movies, handlePrev, handleNext, currentPage, totalPages }) => {
  return (
    <div>
      <Carousel showThumbs={false} autoPlay infiniteLoop>
        {movies.map((movie) => (
          <div key={movie.id} style={{ height: '500px' }}>
            <img
              src={`https://image.tmdb.org/t/p/original${movie.backdrop_path}`}
              alt={movie.original_title}
              style={{ height: '100%', objectFit: 'cover' }}
            />
            <div className="legend">
              <h1>{movie.original_title}</h1>
              <p>{movie.overview}</p>
            </div>
          </div>
        ))}
      </Carousel>

      <div style={{ textAlign: 'center', marginTop: '1rem' }}>
        <button onClick={handlePrev} disabled={currentPage === 1}>
          Previous
        </button>
        <span style={{ margin: '0 1rem' }}>
          {currentPage} of {totalPages}
        </span>
        <button onClick={handleNext} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>

      {/* Card Display */}
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
        <Link to={``}/>
        {movies.map((movie) => (
          <Card key={movie.id} movie={movie} />
        ))}
      </div>
    </div>
  );
};

export default Home;
